// LogView.cpp : implementation file
//

#include "stdafx.h"
#include "Client.h"
#include "LogView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CLogView *g_pLogView;
/////////////////////////////////////////////////////////////////////////////
// CLogView

IMPLEMENT_DYNCREATE(CLogView, CEditView)

CLogView::CLogView()
{
	g_pLogView = this;
}

CLogView::~CLogView()
{
}


BEGIN_MESSAGE_MAP(CLogView, CEditView)
	//{{AFX_MSG_MAP(CLogView)
	ON_CONTROL_REFLECT(EN_CHANGE, OnChange)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLogView drawing

void CLogView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
}

/////////////////////////////////////////////////////////////////////////////
// CLogView diagnostics

#ifdef _DEBUG
void CLogView::AssertValid() const
{
	CEditView::AssertValid();
}

void CLogView::Dump(CDumpContext& dc) const
{
	CEditView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CLogView message handlers

void CLogView::OnInitialUpdate() 
{
	CEditView::OnInitialUpdate();
	// TODO: Add your specialized code here and/or call the base class
	CFont *pFont = new CFont;
	pFont->CreatePointFont(90, "����");
	
	this->SetFont(pFont);
	m_nCurSel = GetEditCtrl().GetWindowTextLength();
}

void CLogView::AddToLog(CString str)
{	
	CTime time = CTime::GetCurrentTime(); ///����CTime���� 
	CString strTime;
	
	str += "\r\n";
	int	len = GetEditCtrl().GetWindowTextLength();
	GetEditCtrl().SetSel(len, len);
	strTime.Format("[%s]	%s", time.Format("%Y-%m-%d %H:%M:%S"), str);
	GetEditCtrl().ReplaceSel(strTime);
	m_nCurSel = GetEditCtrl().GetWindowTextLength();
	
}

void CLogView::OnChange() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CEditView::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	int len = GetEditCtrl().GetWindowTextLength();
	if (len < m_nCurSel)
		m_nCurSel = len;
	// TODO: Add your control notification handler code here
	
}

